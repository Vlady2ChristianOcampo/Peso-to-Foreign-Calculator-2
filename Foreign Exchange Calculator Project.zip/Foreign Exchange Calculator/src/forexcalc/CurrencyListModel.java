/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package forexcalc;
import javax.swing.*;
import javax.swing.event.ListDataListener;
import java.util.*;

/**
 * This currency list contains the names of the currencies for a jList.
 * @author Ocampo
 * @param <E> type of data this model holds. Usually a string
 */
public class CurrencyListModel<E> implements ListModel<E> {

    private final E[] data;
    
    public CurrencyListModel(E[] data) {
        this.data = data;
    }
    
    public CurrencyListModel(List<E> data) {
        this.data = (E[])data.toArray();
    }
    
    @Override
    public int getSize() {
        return this.data.length;
    }

    @Override
    public E getElementAt(int index) {
        return this.data[index];
    }

    @Override
    public void addListDataListener(ListDataListener l) {
        
    }

    @Override
    public void removeListDataListener(ListDataListener l) {
        
    }
    
}
