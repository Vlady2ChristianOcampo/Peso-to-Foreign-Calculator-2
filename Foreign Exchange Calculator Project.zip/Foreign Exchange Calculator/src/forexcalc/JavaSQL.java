
package forexcalc;
import java.sql.*;

/**
 * This class packages the objects needed for the MySQL JDBC. Requires a JDBC
 * driver.
 * @author Vladimir II Christian Ocampo
 */
public class JavaSQL {
    private final String url;
    private final String user;
    private final String password;
    
    /**
     * Construct a JavaSQL object that handles Java-MySQL connectivity
     * @param databaseName The name of the database to be accessed
     * @param port The port used
     * @param user MySQL user
     * @param password MySQL password
     */
    public JavaSQL(String databaseName, String port, String user, String password) {
        this.url = "jdbc:mysql://localhost:" + port + "/" + databaseName;
        this.user = user;
        this.password = password;
    }
    
    // Get URL
    /**
     * Retreives the JDBC MySQL URL.
     * @return The JDBC MySQL URL as a String.
     */
    public String getURL() {
        return this.url;
    }
    
    // Get user and password
    /**
     * Retreives the MySQL user.
     * @return MySQL user.
     */
    public String getUser() {
        return this.user;
    }
    
    /**
     * Retreives the MySQL password
     * @return MySQL password
     */
    public String getPassword() {
        return this.password;
    }
    
    /**
     * Establish the connection to MySQL. This connection is where statements
     * and queries can be carried out.
     * @return Connection to MySQL.
     * @throws ClassNotFoundException If the JDBC Driver cannot be found
     * @throws SQLException if there is an error accessing MySQL
     */
    public Connection getConnection() throws ClassNotFoundException, SQLException {
        Class.forName("com.mysql.jdbc.Driver");
        return DriverManager.getConnection(this.url, this.user, this.password);
    }
}
